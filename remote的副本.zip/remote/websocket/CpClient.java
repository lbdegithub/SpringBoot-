package com.tf56.iloop.tms.web.remote.websocket;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

/**
 * 城配客户端
 *
 * @author LiBin
 * @date 2020-04-14 2:54 下午
 **/
public class CpClient extends WebSocketClient {

    public CpClient(URI serverUri) {
        super(serverUri);
    }

    @Override
    public void onOpen(ServerHandshake handshakedata) {
        // 建立连接完成
    }

    @Override
    public void onMessage(String message) {
        // 收到消息
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        // 连接关闭
    }

    @Override
    public void onError(Exception ex) {
        // 连接异常
    }
}
