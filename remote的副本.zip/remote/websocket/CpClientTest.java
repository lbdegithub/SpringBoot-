package com.tf56.iloop.tms.web.remote.websocket;

import com.alibaba.fastjson.JSONObject;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Objects;

/**
 * 城配客户端
 *
 * @author LiBin
 * @date 2020-04-14 2:54 下午
 **/
public class CpClientTest {

    public static final String CP_SERVER_URL = "ws://10.50.9.43:8888/demo";

    private WebSocketClient webSocketClient = null;

    public void sendMsg(String msg) {
        try {
            checkConnection();
            webSocketClient.send(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendMsg(Object o) {
        sendMsg(JSONObject.toJSONString(o));
    }

    public String getReadyState() {
        if (Objects.isNull(webSocketClient)) {
            return "";
        }
        return webSocketClient.getReadyState().toString();
    }

    private void checkConnection() throws Exception {
        if (Objects.isNull(webSocketClient)) {
            createConnection();
        }

        if (webSocketClient.isClosed()) {
            webSocketClient.reconnectBlocking();
        }
    }

    private void createConnection() throws URISyntaxException, InterruptedException {
        webSocketClient = new WebSocketClient(new URI(CP_SERVER_URL)) {
            @Override
            public void onOpen(ServerHandshake serverHandshake) {
                System.out.println(this.getReadyState());
                System.out.println("连接完成");
            }

            @Override
            public void onMessage(String s) {
                System.out.println(this.getReadyState());
                System.out.println("服务端发来消息：" + s);
            }

            @Override
            public void onClose(int i, String s, boolean b) {
                System.out.println(this.getReadyState());
                System.out.println("连接关闭");
            }

            @Override
            public void onError(Exception e) {
                System.out.println(this.getReadyState());
                System.out.println("连接异常");
                e.printStackTrace();
            }
        };

        webSocketClient.connectBlocking();
    }

    public static void main(String[] args) {
        try {
            CpClientTest cpClient = new CpClientTest();
            cpClient.createConnection();
            cpClient.sendMsg("123");
        } catch (Exception e) {
            e.printStackTrace();
        }


        //		<dependency>
		//	<groupId>org.java-websocket</groupId>
		//	<artifactId>Java-WebSocket</artifactId>
		//	<version>1.4.0</version>
		//</dependency>
    }
}
