package com.tf56.iloop.tms.web.remote.websocket;

import com.alibaba.fastjson.JSONObject;
import com.tf56.iloop.common.exception.TmsException;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * websocket消息发送支持
 * // TODO 异步处理
 *
 * @author LiBin
 * @date 2020-04-14 7:13 下午
 **/
@Component
public class CpClientSupport {

    private Map<String, CpClient> cpClientCache = new HashMap<>();

    public void sendMsg(Object msg, String partyId) {
        sendMsg(JSONObject.toJSONString(msg), partyId);
    }

    public void sendMsg(String msg, String partyId) {
        doSendMsg(msg, partyId);
    }

    private void doSendMsg(String msg, String partyId) {
        if (StringUtils.isBlank(partyId)) {
            throw new TmsException("partyId 不可以为空");
        }

        CpClient cpClient = getCpClient(partyId);
    }

    private CpClient getCpClient(String partyId) {
        CpClient cpClient = cpClientCache.get(partyId);
        if (Objects.nonNull(cpClient)) {
            return cpClient;
        }

        try {
            cpClient = new CpClient(new URI(getUrlByPartyId(partyId)));
        } catch (URISyntaxException e) {
            throw new TmsException("partyId 不可以为空");
        }
        return cpClient;

    }

    private String getUrlByPartyId(String partyId) {
        // TODO 根据企业获取对应的URL
        // ws://cp.zjyypt.net/ws-receive/greenDelivery/{accessToken}  主要是获取accessToken
        return CpClientTest.CP_SERVER_URL;
    }
}
